# Escape the Valley - Run Instructions

1. Unzip escape-the-valley folder (doesn't matter where you extract the files to, you just need to be able to access them)
2. Navigate to the build folder
3. Find the file named 'escape-the-valley.exe'
4. Open it!